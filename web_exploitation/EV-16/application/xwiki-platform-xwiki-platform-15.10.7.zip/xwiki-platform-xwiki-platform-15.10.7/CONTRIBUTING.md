See [How to contribute](https://dev.xwiki.org/xwiki/bin/view/Community/Contributing).
