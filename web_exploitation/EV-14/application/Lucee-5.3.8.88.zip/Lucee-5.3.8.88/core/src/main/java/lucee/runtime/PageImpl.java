package lucee.runtime;

// FUTURE add to Page and delete this class
public abstract class PageImpl extends Page implements PagePro {

	public int getHash() {
		return 0;
	}

	public long getSourceLength() {
		return 0;
	}
}
