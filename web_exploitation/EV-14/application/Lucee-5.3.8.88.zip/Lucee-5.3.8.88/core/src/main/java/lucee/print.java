package lucee;

public final class print extends aprint {}