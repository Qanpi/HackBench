package lucee.runtime;

// FUTURE add to Page and delete
public interface PagePro {

	public int getHash();

	public long getSourceLength();
}
